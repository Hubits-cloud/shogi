# Shogi
## Video Demo:
[My video](https://youtu.be/OC3wZnsJh3s)
### Description:
For my project i decided on making a game called Shogi, wich is basically the japanese version of chess. The game is played on a 9-by-9 grid of squares, where there is a white side, and a black side.
The black side starts at the bottom of the board, and also makes the first move. The challenger is the one who uses the black pieces.
There are in total 20 pieces on each side, 9 pawns, 1 bishop, 1 rook, 2 lances, 2 knights, 2 silver generals, 2 gold generals, and 1 king. The pieces are spread around the three last rows on each side, where the bishops and rooks are alone on the middle rows. And unlike chess every piece except the king, and gold general, can be promoted to their own specific piece.

### Design changes:
My game is not completely like shogi. I decided to change some things to both make the game simpler in case you haven't played shogi before, and because of time constraints. The things i changed are the following:
The capture and drop system. In regular shogi when you capture a piece you can use a turn to "drop" the piece as one of your own. I decided to drop this feature because when i started playing shogi with my mate, we either forgot to use to captured pieces or relied too much on them. And it would also be a massive amount of extra work to add the feature because of the rules around dropping a piece.
The promotion system. In shogi the field of promotion are your rivals last three rows, but i decided to make that one row instead in order to make it more risky to promoted your pieces, espicially the rook and bishop,

### Rules:
The rules for shogi are quite simple, black starts, and the game ends when a king is captured or cant escape. Unlike in actual shogi, in my version you don't get to use your opponents pieces when captured, and you can only promote your pieces on the last row like chees.

### Pawns:
Pawns start at the front row and completely fill set row. And unlike in chess pawns in shogi can only move one square at a time, and the pawn en passant move dosen't exist in shogi. Pawns can only capture the pieces right in front of them. The promoted pawn (*tokin*) can be aqquired by promoting a pawn at your rivals last row. A promoted pawn can move to all adjacent squares except the bottom two corners.

### Lances:
Lances are a unique piece to shogi. Lances start in the two bottom corners and can only move forward, but they can move as far as they want, until they hit either a friendly or an rival piece. The promoted lance (*narikyō*) can be aqquired by promoting a lance at your rivals last row. A promoted lance can move to all adjacent squares except the bottom two corners.

### Knight:
Knights start at the last row next to the lances, and behind either the bishop or rook. Unlike in chess the knight can only move to the two square furthest ahead, but the knight can still jump over other pieces. The promoted knight (*narikei*) can be aqquired by promoting a knight at your rivals last row. A promoted knight can move to all adjacent squares except the bottom two corners, and can no longer jump.

### Silver general:
Silver genrals are another unique piece to shogi. Silver generals start between knights and gold generals. Silver generals can move to all adjacent squares except the ones to the right, left and behind the silver general. The promoted silver general (*narigin*) can be aqquired by promoting a silver general at your rivals last row. A promoted silver general can move to all adjacent squares except the bottom two corners.

### Gold general:
Gold generals are another unique piece to shogi. Gold generals start next to silver generals and the king. Gold generals can move to all adjacent squares except the bottom two corners. Gold generals are one of the two pieces in shogi that can't be promoted.

### Bishop:
The bishops starts in a different spot depending on whether you're the challenger or the champion. If you're the challenger your bishop starts in square (b,2), and if you're the champion your bishop starts in (h,8). Just like in chess the bishop moves diagonally as far as it wants until obstructed by either a piece or the edge of the board. The promoted bishop (*ryūma aka the dragon horse*) can be aqquired by moving your bishop to your rivals last row. The promoted bishop can move to all adjacent squares but keeps it's ability to move diagonally as far as possible until obstructed.

### Rook:
The rook starts in a different spot depending on whether you're the challanger or the champion. If you're the challenger your rook starts in square (h,2), and if you're the champion your rook starts in square (b,8). Just like in chess the rook can moves forwards, backwards, and to the sides as far as it wants until obstructed. The promoted rook (*ryūō aka the dragon king*) can be aqquired by moving your rook to your rivals last row. The promoted rook can move to all adjacent squares but keeps it's ability to move forwards, backwars, and to the sides as far as it wants until obstructed.

### King:
The king starts between the two gold generals. Just like chess the king can move to all adjacent squares, and if your king is captured you lose the game. The king is the other of the two pieces in shogi that can't be promoted.

### Help: 
Huge thanks to coding spot for his [chess video](https://www.youtube.com/watch?v=OpL0Gcfn4B4&list=LL&index=64)