import os
class piece:

    def __init__(self, name, color, value, texture=None, texture_rect=None):
        self.name = name
        self.color = color

        value_sign = 1 if color == 'black' else -1
        self.value = value * value_sign
        self.moves = []
        self.moved = False
        self.texture = texture
        self.set_texture()
        self.texture_rect = texture_rect

    #load textures
    def set_texture(self,size=80):
        self.texture = os.path.join(
            f'assets/images/imgs-{size}px/{self.color}_{self.name}.png'
        )

    def add_move(self, move):
        self.moves.append(move)

    def clear_moves(self):
        self.moves = []

#creates the pawn
class pawn(piece):

    def __init__(self, color):
        #makes sure the pawn can only move up the board
        self.dir = -1 if color == 'black' else 1
        super().__init__('pawn', color, 1.0)

class promotedPawn(piece):

    def __init__(self, color):
        super().__init__('promotedPawn', color, 4.2)

class Knight(piece):

    def __init__(self, color):
        self.dir = -1 if color == 'black' else 1
        super().__init__('knight', color, 4.5)

class promotedKnight(piece):
    
    def __init__(self, color):
        super().__init__('promotedKnight', color, 6.4)

class Lance(piece):

    def __init__(self, color):
        self.dir = -1 if color == 'black' else 1
        super().__init__('Lance', color, 4.3)

class promotedLance(piece):
    
    def __init__(self, color):
        super().__init__('promotedLance', color, 6.3)

class silverGeneral(piece):

    def __init__(self, color):
        super().__init__('silverGeneral', color, 6.4)

class promotedSilverGeneral(piece):

    def __init__(self, color):
        super().__init__('promotedSilverGeneral', color, 6.7)

class goldGeneral(piece):

    def __init__(self, color):
        super().__init__('goldGeneral', color, 6.9)


class bishop(piece):

    def __init__(self, color):
        super().__init__('Bishop', color, 8.9)

class promotedBishop(piece):

    def __init__(self, color):
        super().__init__('promotedBishop', color, 11.5)

class rook(piece):

    def __init__(self, color):
        super().__init__('Rook', color, 10.4)

class promotedRook(piece):
    
    def __init__(self, color):
        super().__init__('promotedRook', color, 13.0)

class King(piece):

    def __init__(self, color):
        super().__init__('King', color, 10000.0)