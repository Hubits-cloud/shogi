#Screen dimensions
WIDTH = 900
HEIGHT = 900

#board dimensions
ROWS = 9
COLS = 9
SQSIZE = HEIGHT // ROWS