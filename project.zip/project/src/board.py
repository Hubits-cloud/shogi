from constant import *
from square import Square
from piece import *
from move import Move
import copy

class Board:

    def __init__(self):
        #create a 2d array
        self.squares = [[0, 0, 0, 0, 0, 0, 0, 0, 0] for col in range(COLS)]
        self.last_move = None
        self._create()
        self._ad_pieces('black')
        self._ad_pieces('white')

    def move(self, piece, move):
        initial = move.initial
        final = move.final

        #console board move update
        self.squares[initial.row][initial.col].piece = None
        self.squares[final.row][final.col].piece = piece

        # promotion
        if isinstance(piece, pawn):
            self.promotion_pawn(piece, final)

        if isinstance(piece, Lance):
            self.promotion_lance(piece, final)

        if isinstance(piece, Knight):
            self.promotion_knight(piece, final)
        
        if isinstance(piece, bishop):
            self.promotion_bishop(piece, final)

        if isinstance(piece, rook):
            self.promotion_rook(piece, final)
        
        if isinstance(piece, silverGeneral):
            self.promotion_Sgeneral(piece, final)

        #move
        piece.moved = True

        # clear valid moves
        piece.clear_moves()

        #set last move
        self.last_move = move

    def valid_move(self, piece, move):
        return move in piece.moves
    
    # TODO
    def promotion_pawn(self, piece, final):
        if piece.color == 'black':
            if final.row == 0:
                self.squares[final.row][final.col].piece = promotedPawn(piece.color)
            else: return
        else:
            if final.row == 8:
                self.squares[final.row][final.col].piece = promotedPawn(piece.color)

    def promotion_lance(self, piece, final):
        if piece.color == 'black':
            if final.row == 0:
                self.squares[final.row][final.col].piece = promotedLance(piece.color)
            else: return
        else:
            if final.row == 8:
                self.squares[final.row][final.col].piece = promotedLance(piece.color)

    def promotion_knight(self, piece, final):
        if piece.color == 'black':
            if final.row == 0:
                self.squares[final.row][final.col].piece = promotedKnight(piece.color)
            else: return
        else:
            if final.row == 8:
                self.squares[final.row][final.col].piece = promotedKnight(piece.color)

    def promotion_bishop(self, piece, final):
        if piece.color == 'black':
            if final.row == 0:
                self.squares[final.row][final.col].piece = promotedBishop(piece.color)
            else: return
        else:
            if final.row == 8:
                self.squares[final.row][final.col].piece = promotedBishop(piece.color)

    def promotion_rook(self, piece, final):
        if piece.color == 'black':
            if final.row == 0:
                self.squares[final.row][final.col].piece = promotedRook(piece.color)
            else: return
        else:
            if final.row == 8:
                self.squares[final.row][final.col].piece = promotedRook(piece.color)

    def promotion_Sgeneral(self, piece, final):
        if piece.color == 'black':
            if final.row == 0:
                self.squares[final.row][final.col].piece = promotedSilverGeneral(piece.color)
            else: return
        else:
            if final.row == 8:
                self.squares[final.row][final.col].piece = promotedSilverGeneral(piece.color)

    def in_check(self, piece, move):
        temp_piece = copy.deepcopy(piece)
        temp_board = copy.deepcopy(self)
        temp_board.move(temp_piece, move)

        for row in range(ROWS):
            for col in range(COLS):
                if temp_board.squares[row][col].has_rival_piece(piece.color):
                    p = temp_board.squares[row][col].piece
                    temp_board.calc_moves(p, row, col, bool=False)
                    for m in p.moves:
                        if isinstance(m.final.piece, King):
                            return True
        
        return False

    def calc_moves(self, piece, row, col, bool=True):
        '''
            calculate all valid moves of an specific piece on a specific position
        '''
        def pawn_moves():

            black_moves = [
                (row-1, col+0), # up
            ]

            white_moves =[
                (row+1, col+0)
            ]

            if piece.color == 'black':
                for move in black_moves:
                    possible_move_row, possible_move_col = move

                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                                initial = Square(row, col)
                                final_piece = self.squares[possible_move_row][possible_move_col].piece
                                final = Square(possible_move_row, possible_move_col, final_piece)
                                # create new move
                                move = Move(initial, final)

                                # check for check
                                if bool:
                                    if not self.in_check(piece, move):
                                        #append new valid move
                                        piece.add_move(move)
                                else:
                                    #append new valid move
                                    piece.add_move(move)

            else:
                for move in white_moves:
                    possible_move_row, possible_move_col = move

                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                                initial = Square(row, col)
                                final_piece = self.squares[possible_move_row][possible_move_col].piece
                                final = Square(possible_move_row, possible_move_col, final_piece)
                                # create new move
                                move = Move(initial, final)
                                # check for check
                                if bool:
                                    if not self.in_check(piece, move):
                                        #append new valid move
                                        piece.add_move(move)
                                else:
                                    #append new valid move
                                    piece.add_move(move)

        def straightline_moves(incrs):
            for incr in incrs:
                row_incr, col_incr = incr
                possible_move_row = row + row_incr
                possible_move_col = col + col_incr

                while True:
                    if Square.in_range(possible_move_row, possible_move_col):

                        #create squares of the possible new move
                        initial = Square(row, col)
                        final_piece = self.squares[possible_move_row][possible_move_col].piece
                        final = Square(possible_move_row, possible_move_col, final_piece)

                        # create the move
                        move = Move(initial, final)
                        
                        # empty = continue looping
                        if self.squares[possible_move_row][possible_move_col].is_empty():
                            # check for check
                                if bool:
                                    if not self.in_check(piece, move):
                                        #append new valid move
                                        piece.add_move(move)
                                else:
                                    #append new valid move
                                    piece.add_move(move)

                        # has enemy piece = add move + break
                        elif self.squares[possible_move_row][possible_move_col].has_rival_piece(piece.color):
                            if bool:
                                if not self.in_check(piece, move):
                                    #append new valid move
                                    piece.add_move(move)
                            else:
                                #append new valid move
                                piece.add_move(move)
                            break

                        #has team piece = break
                        elif self.squares[possible_move_row][possible_move_col].team_piece(piece.color):
                            break

                    # not in range
                    else: break

                    # incrementing the incrs
                    possible_move_row = possible_move_row + row_incr 
                    possible_move_col = possible_move_col + col_incr

        def knight_moves():
            black_possible_moves = [
                (row-2, col+1),
                (row-2, col-1),
            ]
            
            white_possible_moves = [
                (row+2, col+1),
                (row+2, col-1),
            ]

            if piece.color == 'black':
                for possible_move in black_possible_moves:
                    possible_move_row, possible_move_col = possible_move
                    
                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                            initial = Square(row, col)
                            final_piece = self.squares[possible_move_row][possible_move_col].piece
                            final = Square(possible_move_row, possible_move_col, final_piece)
                            # create new move
                            move = Move(initial, final)
                            # check for check
                            if bool:
                                if not self.in_check(piece, move):
                                    #append new valid move
                                    piece.add_move(move)
                                else: break
                            else:
                                #append new valid move
                                piece.add_move(move)

            else:
                for possible_move in white_possible_moves:
                    possible_move_row, possible_move_col = possible_move
                    
                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                            initial = Square(row, col)
                            final_piece = self.squares[possible_move_row][possible_move_col].piece
                            final = Square(possible_move_row, possible_move_col, final_piece)
                            # create new move
                            move = Move(initial, final)
                            # check for check
                            if bool:
                                if not self.in_check(piece, move):
                                    #append new valid move
                                    piece.add_move(move)
                                else: break
                            else:
                                #append new valid move
                                piece.add_move(move)

        def gold_moves():
            black_moves = [
                (row-1, col+0), # up
                (row-1, col+1), # up right
                (row+0, col+1), # right
                (row+1, col+0), # down
                (row+0, col-1), # left
                (row-1, col-1), # up left
            ]

            white_moves = [
                (row-1, col+0),
                (row+0, col+1), 
                (row+1, col+1), 
                (row+1, col+0), 
                (row+1, col-1), 
                (row+0, col-1), 
            ]

            if piece.color == 'black':
                for adj in black_moves:
                    possible_move_row, possible_move_col = adj

                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                                initial = Square(row, col)
                                final_piece = self.squares[possible_move_row][possible_move_col].piece
                                final = Square(possible_move_row, possible_move_col, final_piece)
                                # create new move
                                move = Move(initial, final)
                                # check for check
                                if bool:
                                    if not self.in_check(piece, move):
                                        #append new valid move
                                        piece.add_move(move)
                                else:
                                    #append new valid move
                                    piece.add_move(move)
            else:
                for adj in white_moves:
                    possible_move_row, possible_move_col = adj

                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                                initial = Square(row, col)
                                final_piece = self.squares[possible_move_row][possible_move_col].piece
                                final = Square(possible_move_row, possible_move_col, final_piece)
                                # create new move
                                move = Move(initial, final)
                                # check for check
                                if bool:
                                    if not self.in_check(piece, move):
                                        #append new valid move
                                        piece.add_move(move)
                                else:
                                    #append new valid move
                                    piece.add_move(move)

        def king_moves():
            adjs = [
                (row-1, col+0), # up
                (row-1, col+1), # up right
                (row+0, col+1), # right
                (row+1, col+1), # down right
                (row+1, col+0), # down
                (row+1, col-1), # down left
                (row+0, col-1), # left
                (row-1, col-1), # up left
            ]

            #normal moves
            for adj in adjs:
                possible_move_row, possible_move_col = adj

                if Square.in_range(possible_move_row, possible_move_col):
                    if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                        # create the squares needed for the new move
                            initial = Square(row, col)
                            final = Square(possible_move_row, possible_move_col)
                            # create new move
                            move = Move(initial, final)
                            if bool:
                                if not self.in_check(piece, move):
                                    #append new valid move
                                    piece.add_move(move)
                                else: break
                            else:
                                #append new valid move
                                piece.add_move(move)

        def silver_moves():
            black_moves = [
                (row-1, col+0), # up
                (row-1, col+1), # up right
                (row+1, col+1), # down right
                (row+1, col-1), # down left
                (row-1, col-1), # up left
            ]

            white_moves = [
                (row-1, col+1), 
                (row+1, col+1), 
                (row+1, col+0), 
                (row+1, col-1), 
                (row-1, col-1), 
            ]

            if piece.color == 'black':
                for adj in black_moves:
                    possible_move_row, possible_move_col = adj

                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                                initial = Square(row, col)
                                final_piece = self.squares[possible_move_row][possible_move_col].piece
                                final = Square(possible_move_row, possible_move_col, final_piece)
                                # create new move
                                move = Move(initial, final)
                                # check for check
                                if bool:
                                    if not self.in_check(piece, move):
                                        #append new valid move
                                        piece.add_move(move)
                                else:
                                    #append new valid move
                                    piece.add_move(move)
            else:
                for adj in white_moves:
                    possible_move_row, possible_move_col = adj

                    if Square.in_range(possible_move_row, possible_move_col):
                        if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                            # create the squares needed for the new move
                                initial = Square(row, col)
                                final_piece = self.squares[possible_move_row][possible_move_col].piece
                                final = Square(possible_move_row, possible_move_col, final_piece)
                                # create new move
                                move = Move(initial, final)
                                # check for check
                                if bool:
                                    if not self.in_check(piece, move):
                                        #append new valid move
                                        piece.add_move(move)
                                else:
                                    #append new valid move
                                    piece.add_move(move)

        def dragonHorse_moves():
            adjs = [
                (row-1, col+0), # up
                (row+0, col+1), # right
                (row+1, col+0), # down
                (row+0, col-1), # left
            ]

            #normal moves
            for adj in adjs:
                possible_move_row, possible_move_col = adj

                if Square.in_range(possible_move_row, possible_move_col):
                    if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                        # create the squares needed for the new move
                            initial = Square(row, col)
                            final_piece = self.squares[possible_move_row][possible_move_col].piece
                            final = Square(possible_move_row, possible_move_col, final_piece)
                            # create new move
                            move = Move(initial, final)
                           # check for check
                            if bool:
                                if not self.in_check(piece, move):
                                    #append new valid move
                                    piece.add_move(move)
                            else:
                                #append new valid move
                                piece.add_move(move)

        def dragon_moves():
            adjs = [
                (row-1, col+1), # up right
                (row+1, col+1), # down right
                (row+1, col-1), # down left
                (row-1, col-1), # up left
            ]

            #normal moves
            for adj in adjs:
                possible_move_row, possible_move_col = adj

                if Square.in_range(possible_move_row, possible_move_col):
                    if self.squares[possible_move_row][possible_move_col].empty_or_rival(piece.color):
                        # create the squares needed for the new move
                            initial = Square(row, col)
                            final_piece = self.squares[possible_move_row][possible_move_col].piece
                            final = Square(possible_move_row, possible_move_col, final_piece)
                            # create new move
                            move = Move(initial, final)
                            # check for check
                            if bool:
                                if not self.in_check(piece, move):
                                    #append new valid move
                                    piece.add_move(move)
                            else:
                                #append new valid move
                                piece.add_move(move)
        
        if isinstance(piece, pawn):
            pawn_moves()

        elif isinstance(piece, promotedPawn):
            gold_moves()

        elif isinstance(piece, Lance):
            if piece.color == 'black':
                straightline_moves([
                    (-1, 0),
                ])
            else:
                straightline_moves([
                    (1, 0),
                ])

        elif isinstance(piece, promotedLance):
            gold_moves()

        elif isinstance(piece, Knight):
            knight_moves()

        elif isinstance(piece, promotedKnight):
            gold_moves()
        
        elif isinstance(piece, bishop):
            straightline_moves([
                (-1, 1), #upper right diagonal
                (-1, -1), #upper left
                (1, 1), #down right
                (1, -1), # down left
            ])

        elif isinstance(piece, promotedBishop):
            straightline_moves([
                (-1, 1), #upper right diagonal
                (-1, -1), #upper left
                (1, 1), #down right
                (1, -1), # down left
            ])
            dragonHorse_moves()

        elif isinstance(piece, goldGeneral):
            gold_moves()

        elif isinstance(piece, King):
            king_moves()

        elif isinstance(piece, rook):
            straightline_moves([
                (-1, 0), #up
                (0, 1), # left
                (1, 0), # down
                (0, -1), #right
            ])

        elif isinstance(piece, promotedRook):
            straightline_moves([
                (-1, 0), #up
                (0, 1), # left
                (1, 0), # down
                (0, -1), #right
            ])
            dragon_moves()

        elif isinstance(piece, silverGeneral):
            silver_moves()

        elif isinstance(piece, promotedSilverGeneral):
            gold_moves()

    def _create(self):
    
        #loop set 2d array and replace the 0 with the square object
        for row in range(ROWS):
            for col in range(COLS):
                self.squares[row][col] = Square(row, col) 

    def _ad_pieces(self, color):
        row_pawn, row_rb, row_other = (6, 7, 8) if color == 'black' else (2, 1, 0)

        # these are the pawns
        for col in range(COLS):
            self.squares[row_pawn][col] = Square(row_pawn, col, pawn(color))

        #bishop
        if color == 'black':
            self.squares[row_rb][1] = Square(row_rb, 1, bishop(color))
        else:
            self.squares[row_rb][7] = Square(row_rb, 7, bishop(color))
        
        #rook
        if color == 'black':
            self.squares[row_rb][7] = Square(row_rb, 7, rook(color))
        else:
            self.squares[row_rb][1] = Square(row_rb, 1, rook(color))

        #lance
        self.squares[row_other][0] = Square(row_other, 0, Lance(color))
        self.squares[row_other][8] = Square(row_other, 8, Lance(color))

        #knight
        self.squares[row_other][1] = Square(row_other, 1, Knight(color))
        self.squares[row_other][7] = Square(row_other, 7, Knight(color))

        #Silver general
        self.squares[row_other][2] = Square(row_other, 2, silverGeneral(color))
        self.squares[row_other][6] = Square(row_other, 6, silverGeneral(color))

        #gold general
        self.squares[row_other][3] = Square(row_other, 3, goldGeneral(color))
        self.squares[row_other][5] = Square(row_other, 5, goldGeneral(color))

        #king
        self.squares[row_other][4] = Square(row_other, 4, King(color))

         
        
